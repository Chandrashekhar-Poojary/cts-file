        
const addProduct = async() => {

      var productId = document.getElementById('productId').value;
      var productName = document.getElementById('productName').value;
      var price = document.getElementById('price').value;
      
      let response = await fetch('http://localhost:8080/product');
      console.log(response)
      
      // Post Method
      let response2 = await fetch('http://localhost:8080/product', {
            method: 'POST',
            headers: {
                  'Accept': 'application/json',
                  'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                  "productid": productId,
                  "productname": productName,
                  "price": price
            })
      })
      console.log("Product ID: " + productId);
      console.log("Product Name: " + productName);
      console.log("Price: " + price);       
}